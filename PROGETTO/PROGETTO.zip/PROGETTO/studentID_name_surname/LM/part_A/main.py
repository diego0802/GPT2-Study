import os
import urllib.request
from transformers import AutoTokenizer
from functions import *
from utils import get_dataloaders
from model import GPT2
import torch.nn as nn

def download_dataset():
    """Scarica i file del Penn Treebank se non esistono"""
    base_url = "https://raw.githubusercontent.com/massimo-rizzoli/NLU-2026-Labs/main/labs/dataset/PennTreeBank/"
    files = ["ptb.train.txt", "ptb.valid.txt", "ptb.test.txt"]
    os.makedirs("dataset/PennTreeBank", exist_ok=True)
    
    for file in files:
        url = base_url + file
        path = f"dataset/PennTreeBank/{file}"
        if not os.path.exists(path):
            print(f"Downloading {file}...")
            urllib.request.urlretrieve(url, path)
        else:
            print(f"{file} already exists")

def experiment_1a():
    # Scarica i dataset se non esistono
    download_dataset()
    
    # Crea il tokenizer
    tokenizer = AutoTokenizer.from_pretrained("openai-community/gpt2")
    tokenizer.pad_token = tokenizer.eos_token
    print(tokenizer.pad_token_id)   # dovrebbe essere 50256 (eos_token_id per GPT2)
    
    # Carica i dati
    train_loader, dev_loader, test_loader, tokenizer = get_dataloaders(
        tokenizer,
        "dataset/PennTreeBank/ptb.train.txt",
        "dataset/PennTreeBank/ptb.valid.txt", 
        "dataset/PennTreeBank/ptb.test.txt",
        batch_size=8
    )
    
    # Crea il criterio di loss
    criterion = nn.CrossEntropyLoss(ignore_index=tokenizer.pad_token_id)
    
    # Configurazioni da testare
    configs = [
        {"lr": 0.001, "d_model": 20, "n_heads": 1, "num_layers": 1, "ff_dim": 20, "dropout": 0.0, "weight_tying": False},
        {"lr": 0.0005, "d_model": 64, "n_heads": 1, "num_layers": 1, "ff_dim": 64, "dropout": 0.0, "weight_tying": False},
        {"lr": 0.0005, "d_model": 64, "n_heads": 4, "num_layers": 1, "ff_dim": 64, "dropout": 0.0, "weight_tying": False},
        {"lr": 0.0005, "d_model": 64, "n_heads": 4, "num_layers": 1, "ff_dim": 64, "dropout": 0.1, "weight_tying": False},
        {"lr": 0.0005, "d_model": 64, "n_heads": 4, "num_layers": 1, "ff_dim": 64, "dropout": 0.1, "weight_tying": True},
        {"lr": 0.0003, "d_model": 128, "n_heads": 4, "num_layers": 2, "ff_dim": 512, "dropout": 0.1, "weight_tying": True},
    ]
    
    results = []
    
    for config in configs:
        print(f"\n=== Testing config: {config} ===")
        
        model = GPT2(
            vocab_size=len(tokenizer),
            pos_emb_size=1024,
            d_model=config["d_model"],
            n_heads=config["n_heads"],
            num_layers=config["num_layers"],
            ff_dim=config["ff_dim"],
            dropout=config["dropout"],
            weight_tying=config["weight_tying"]
        )
        
        best_model, best_ppl, _, _ = train_model(
            model, 
            train_loader, 
            dev_loader, 
            criterion,
            lr=config["lr"],
            n_epochs=40,
            patience=5,
            tokenizer = tokenizer
        )
        
        test_ppl, _ = eval_loop(test_loader, criterion, best_model)
        
        results.append({
            "config": config,
            "best_val_ppl": best_ppl,
            "test_ppl": test_ppl
        })
        
        print(f"Val PPL: {best_ppl:.2f}, Test PPL: {test_ppl:.2f}")
    
    print("\n=== Final Results ===")
    for r in results:
        c = r["config"]
        print(f"d_model={c['d_model']}, n_heads={c['n_heads']}, layers={c['num_layers']}, "
              f"dropout={c['dropout']}, tying={c['weight_tying']}\t"
              f"Val: {r['best_val_ppl']:.2f}\tTest: {r['test_ppl']:.2f}")

if __name__ == "__main__":
    experiment_1a()