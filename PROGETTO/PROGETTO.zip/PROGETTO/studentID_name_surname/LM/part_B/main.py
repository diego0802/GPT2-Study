import torch
import torch.nn as nn
import torch.optim as optim
from transformers import AutoTokenizer, GPT2Config, GPT2LMHeadModel
from model import GPT2_LoRA
from utils import get_dataloaders
from functions import eval_loop_1b, train_loop_1b

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

def experiment_1b():
    print(f"Using device: {DEVICE}")
    
    # 1. Carica tokenizer
    tokenizer = AutoTokenizer.from_pretrained("openai-community/gpt2")
    tokenizer.pad_token = tokenizer.eos_token
    
    # 2. Carica dati
    train_loader, dev_loader, test_loader, tokenizer = get_dataloaders(
        tokenizer,
        "dataset/PennTreeBank/ptb.train.txt",
        "dataset/PennTreeBank/ptb.valid.txt",
        "dataset/PennTreeBank/ptb.test.txt",
        batch_size=8,
        device=DEVICE
    )
    
    # 3. Configurazioni LoRA da testare
    configs = [
        {"rank": 1, "alpha": 1, "lr": 1e-4},
        {"rank": 2, "alpha": 1, "lr": 1e-4},
        {"rank": 4, "alpha": 1, "lr": 5e-5},
        {"rank": 8, "alpha": 2, "lr": 5e-5},
        {"rank": 16, "alpha": 2, "lr": 2e-5},
    ]
    
    results = []
    
    for config in configs:
        print(f"\n=== Testing LoRA config: {config} ===")
        
        # 4. Carica modello pre-addestrato e applica LoRA
       # Carica il modello pre-addestrato (con i pesi!)
        model = GPT2LMHeadModel.from_pretrained("openai-community/gpt2")

        # Poi sostituisci le attenzioni con i layer LoRA
        from model import CustomGPT2Attention
        for block in model.transformer.h:
            original_attn = block.attn
            block.attn = CustomGPT2Attention(original_attn, config["rank"], config["alpha"])

        # Congela tutti i pesi tranne i layer LoRA
        for param in model.parameters():
            param.requires_grad = False
        for module in model.modules():
            if hasattr(module, 'lora_q_A'):
                for param in module.parameters():
                    param.requires_grad = True
        model.to(DEVICE)
        
        # 5. Verifica che solo i layer LoRA siano trainabili
        trainable_params = 0
        for name, param in model.named_parameters():
            if param.requires_grad:
                print(f"Trainable: {name}")
                trainable_params += param.numel()
        print(f"Total trainable params: {trainable_params:,}")
        
        # 6. Ottimizzatore e loss
        optimizer = optim.AdamW(
            (p for p in model.parameters() if p.requires_grad),
            lr=config["lr"]
        )
        
        # 7. Training
        n_epochs = 10
        patience = 3
        best_ppl = float('inf')
        best_model = None
        patience_counter = patience
        
        # Nel loop delle epoche
        for epoch in range(n_epochs):
            loss = train_loop_1b(train_loader, optimizer, model, tokenizer)

            # Valuta sul dev set OGNI epoca (non solo ogni 5)
            ppl_dev, loss_dev = eval_loop_1b(dev_loader, model, tokenizer)
            
            # Stampa come nell'1A
            print(f"Epoch {epoch}: Train Loss={loss:.4f} | Dev Loss={loss_dev:.4f} | PPL={ppl_dev:.2f}")
            
            # Ogni epoca (o ogni 5), valuta sul dev set
            if epoch % 1 == 0:  # ogni epoca
                ppl_dev, loss_dev = eval_loop_1b(dev_loader, model, tokenizer)
                print(f"Epoch {epoch}: Train Loss={loss:.4f} | Dev Loss={loss_dev:.4f} | Dev PPL={ppl_dev:.2f}")
                
                # Early stopping
                if ppl_dev < best_ppl:
                    best_ppl = ppl_dev
                    best_model = model.state_dict()
                    patience_counter = patience
                else:
                    patience_counter -= 1
                    if patience_counter <= 0:
                        break
        
        # 8. Test
        model.load_state_dict(best_model)
        test_ppl, _ = eval_loop_1b(test_loader, model, tokenizer)
        
        results.append({
            "config": config,
            "best_val_ppl": best_ppl,
            "test_ppl": test_ppl
        })
        
        print(f"Test PPL: {test_ppl:.2f}")
    
    # 9. Stampa risultati
    print("\n=== Final Results ===")
    for r in results:
        c = r["config"]
        print(f"rank={c['rank']}, alpha={c['alpha']}, lr={c['lr']} → "
              f"Val PPL: {r['best_val_ppl']:.2f}, Test PPL: {r['test_ppl']:.2f}")

if __name__ == "__main__":
    experiment_1b()