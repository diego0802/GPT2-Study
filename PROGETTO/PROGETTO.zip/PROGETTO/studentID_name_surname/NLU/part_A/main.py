import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from utils import *
from model import GPT2
from functions import init_weights, train_loop, eval_loop

def experiment_2a():
    # Load data
    train_raw = load_data('dataset/ATIS/train.json')
    test_raw = load_data('dataset/ATIS/test.json')
    train_raw, dev_raw = create_dev_set(train_raw, portion=0.10)
    
    # Dataloaders
    train_loader, dev_loader, test_loader, lang = get_dataloaders(
        train_raw, dev_raw, test_raw, batch_size=128
    )
    
    # Configs
    configs = [
        {"lr": 0.01, "d_model": 20, "n_heads": 1, "num_layers": 1, "ff_dim": 20, "dropout": 0.0},
        {"lr": 0.005, "d_model": 64, "n_heads": 1, "num_layers": 1, "ff_dim": 64, "dropout": 0.0},
        {"lr": 0.005, "d_model": 64, "n_heads": 4, "num_layers": 1, "ff_dim": 64, "dropout": 0.0},
        {"lr": 0.005, "d_model": 64, "n_heads": 4, "num_layers": 1, "ff_dim": 64, "dropout": 0.1},
        {"lr": 0.001, "d_model": 128, "n_heads": 4, "num_layers": 2, "ff_dim": 512, "dropout": 0.1},
    ]
    
    results = []
    
    for config in configs:
        print(f"\n=== Testing config: {config} ===")
        
        model = GPT2(
            vocab_size=len(lang.word2id),
            slots_size=len(lang.id2slot),
            n_intents=len(lang.intent2id),
            d_model=config["d_model"],
            n_heads=config["n_heads"],
            num_layers=config["num_layers"],
            ff_dim=config["ff_dim"],
            dropout=config["dropout"]
        ).to(DEVICE)
        model.apply(init_weights)
        
        optimizer = optim.AdamW(model.parameters(), lr=config["lr"])
        criterion_slots = nn.CrossEntropyLoss(ignore_index=PAD_TOKEN)
        criterion_intents = nn.CrossEntropyLoss()
        
        n_epochs = 200
        patience = 3
        best_f1 = 0
        best_model = None
        
        for epoch in range(n_epochs):
            loss = train_loop(train_loader, optimizer, criterion_slots, criterion_intents, model)
            
            if epoch % 5 == 0:
                results_dev, intent_res, loss_dev = eval_loop(
                    dev_loader, criterion_slots, criterion_intents, model, lang
                )
                f1 = results_dev['total']['f']
                print(f"Epoch {epoch}: Slot F1={f1:.3f}, Intent Acc={intent_res['accuracy']:.3f}")
                
                if f1 > best_f1:
                    best_f1 = f1
                    best_model = model.state_dict()
                    patience = 3
                else:
                    patience -= 1
                    if patience <= 0:
                        break
        
        # Test
        model.load_state_dict(best_model)
        results_test, intent_test, _ = eval_loop(
            test_loader, criterion_slots, criterion_intents, model, lang
        )
        
        results.append({
            "config": config,
            "slot_f1": results_test['total']['f'],
            "intent_acc": intent_test['accuracy']
        })
        print(f"Test: Slot F1={results_test['total']['f']:.3f}, Intent Acc={intent_test['accuracy']:.3f}")
    
    print("\n=== Final Results ===")
    for r in results:
        c = r["config"]
        print(f"d_model={c['d_model']}, n_heads={c['n_heads']}, layers={c['num_layers']}, "
              f"dropout={c['dropout']} → Slot F1: {r['slot_f1']:.3f}, Intent Acc: {r['intent_acc']:.3f}")

if __name__ == "__main__":
    experiment_2a()