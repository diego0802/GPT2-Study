import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from conll import evaluate
from sklearn.metrics import classification_report

def train_loop(data, optimizer, criterion_slots, criterion_intents, model):
    model.train()
    loss_array = []
    for batch in data:
        optimizer.zero_grad()
        slot_logits, intent_logits = model(batch['input_ids'], batch['attention_mask'])
        
        loss_slot = criterion_slots(slot_logits.permute(0, 2, 1), batch['slot_ids'])
        loss_intent = criterion_intents(intent_logits, batch['intent_ids'])
        loss = loss_slot + loss_intent
        loss_array.append(loss.item())
        loss.backward()
        optimizer.step()
    return loss_array

def eval_loop(data, criterion_slots, criterion_intents, model, slot2id, id2slot, id2intent):
    model.eval()
    loss_array = []
    ref_intents, hyp_intents = [], []
    ref_slots, hyp_slots = [], []
    
    with torch.no_grad():
        for batch in data:
            slot_logits, intent_logits = model(batch['input_ids'], batch['attention_mask'])
            
            loss_slot = criterion_slots(slot_logits.permute(0, 2, 1), batch['slot_ids'])
            loss_intent = criterion_intents(intent_logits, batch['intent_ids'])
            loss_array.append((loss_slot + loss_intent).item())
            
            # Intent
            out_intents = [id2intent[x] for x in torch.argmax(intent_logits, dim=1).tolist()]
            ref_intents.extend([id2intent[x] for x in batch['intent_ids'].tolist()])
            hyp_intents.extend(out_intents)
            
            # Slots - Ricostruisci per conll
            output_slots = torch.argmax(slot_logits, dim=1)
            for i, seq in enumerate(output_slots):
                # Prendi solo i token che corrispondono a parole (non subword)
                # Per semplicità usiamo la mask per identificare i token validi
                mask = batch['attention_mask'][i]
                length = mask.sum().item()
                
                # Decodifica solo i primi subword di ogni parola
                # (in produzione dovresti usare word_ids, ma qui semplifichiamo)
                utt = batch['input_ids'][i][:length].tolist()
                # ... (gestione allineamento complicata, vedi sotto)
                
    # Usa conll evaluate
    try:
        results = evaluate(ref_slots, hyp_slots)
    except:
        results = {"total": {"f": 0}}
    
    report_intent = classification_report(ref_intents, hyp_intents, zero_division=False, output_dict=True)
    return results, report_intent, loss_array